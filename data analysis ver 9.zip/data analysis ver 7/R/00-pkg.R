# ReadMe explains uses
# Imports all needed packages
library(tidyverse)
library(readxl)
library(usethis)
library(knitr)
library(ggplot2)
library(bookdown)
library(RefManageR)
library(grid)
library(gridExtra)
library(R6)
library(stringr)
library(tidytext)
library(textclean)
#library(wordcountaddin) Not currently working with my R version somehow, It's up to date so just manually imported it
