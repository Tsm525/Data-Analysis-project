###############################################################
# Function to check normality then run appropriate stats test #
###############################################################

# Only needed two stats test for this experiment, just t test or wilcox, normality only assumption not met

shapiro_then_stats <- function(group1, group2, column) {
  
  # Check normality of the column for both groups
  s1 <- shapiro.test(group1[[column]])
  s2 <- shapiro.test(group2[[column]])
  
  # If the p-value is >0.05 it is assumed to be normally distributed, both must be for t test hence the AND
  if (s1$p.value > 0.05 && s2$p.value > 0.05) {
    
    #save result for output
    result <- t.test(group1[[column]], group2[[column]])
    
  } else {
    
    # If signifcantly not normal then use a non-parametric test
    result <- wilcox.test(group1[[column]], group2[[column]], paired = FALSE)
    
  }
  
  return(result)
}