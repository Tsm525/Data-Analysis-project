# Creating 3 plots, comparing what happens when we don't move the then when we lower temperature then


fig_25252929 <- obj_25_at_25$graph_all(obj_29_at_29)

fig_25252529 <- obj_25_at_25$graph_all(obj_25_at_29)

fig_29292925 <- obj_29_at_29$graph_all(obj_29_at_25)

#add rectangles
#add boxes
#clearly define graphs
