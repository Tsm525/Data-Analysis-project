library("usethis") # potentially not needed


usethis::use_r("01-import")
usethis::use_directory("data-raw")
usethis::use_directory("data-processed")
usethis::use_directory("figures")
usethis::use_readme_md()
usethis::usethis