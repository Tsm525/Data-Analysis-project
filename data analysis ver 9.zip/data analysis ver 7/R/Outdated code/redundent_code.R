# Don't need anymore, exists in case new methods don't work
r25_m25_summary <- r25_m25 %>% 
  group_by(measured_temp,base_temp) %>% 
  summarise(mean_distance = mean(distance),
            mean_max_speed = mean(max_speed),
            mean_avg_speed = mean(avg_speed),
            std_distance = sd(distance),
            std_max_speed = sd(max_speed),
            std_avg_speed = sd(avg_speed),
            n = length(distance),                # same n for all
            se_distance = std_distance/sqrt(n),
            se_max_speed = std_max_speed/sqrt(n),
            se_avg_speed = std_avg_speed/sqrt(n))

r25_m29_summary <- r25_m29 %>%
  group_by(measured_temp,base_temp) %>% 
  summarise(mean_distance = mean(distance),
            mean_max_speed = mean(max_speed),
            mean_avg_speed = mean(avg_speed),
            std_distance = sd(distance),
            std_max_speed = sd(max_speed),
            std_avg_speed = sd(avg_speed),
            n = length(distance),                
            se_distance = std_distance/sqrt(n),
            se_max_speed = std_max_speed/sqrt(n),
            se_avg_speed = std_avg_speed/sqrt(n))

r29_m29_summary <- r29_m29 %>%
  group_by(measured_temp,base_temp) %>% 
  summarise(mean_distance = mean(distance),
            mean_max_speed = mean(max_speed),
            mean_avg_speed = mean(avg_speed),
            std_distance = sd(distance),
            std_max_speed = sd(max_speed),
            std_avg_speed = sd(avg_speed),
            n = length(distance),               
            se_distance = std_distance/sqrt(n),
            se_max_speed = std_max_speed/sqrt(n),
            se_avg_speed = std_avg_speed/sqrt(n))

r29_m25_summary <- r29_m25 %>%
  group_by(measured_temp,base_temp) %>% 
  summarise(mean_distance = mean(distance),
            mean_max_speed = mean(max_speed),
            mean_avg_speed = mean(avg_speed),
            std_distance = sd(distance),
            std_max_speed = sd(max_speed),
            std_avg_speed = sd(avg_speed),
            n = length(distance),               
            se_distance = std_distance/sqrt(n),
            se_max_speed = std_max_speed/sqrt(n),
            se_avg_speed = std_avg_speed/sqrt(n))



################
# Reared at 25 #
################

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#


## Distance ##

# Run appropriate stats test and save output, ran as T test as normal distribution
distance_results_25 <- shapiro_then_stats(r25_m25,r25_m29,"distance") # p value of 0.9770238

## Max Speed ##

# Ran as wilcoxon, as not normally distributed
max_speed_results_25 <- shapiro_then_stats(r25_m25,r25_m29,"max_speed") # p value of 0.9828

## Average Speed ##

# Ran as wilcoxon, as not normally distributed
avg_speed_results_25 <- shapiro_then_stats(r25_m25,r25_m29,"avg_speed") # p value of 0.5306

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#


################
# Reared at 29 #
################

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#

## Distance ##

# Run appropriate stats test and save output, ran as T test as normal distribution
distance_results_29 <- shapiro_then_stats(r29_m25,r29_m29,"distance") # p value of 0.0.02607 *

## Max Speed ##

# Ran as wilcoxon, as not normally distributed
max_speed_results_29 <- shapiro_then_stats(r29_m25,r29_m29,"max_speed") # p value of 0.5681

## Average Speed ##

# Ran as T test as  normally distributed
avg_speed_results_29 <- shapiro_then_stats(r29_m25,r29_m29,"avg_speed") # p value of 0.7769

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#



#################################
# Comparing Reared at 25 and 29 #
#################################

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#

## Distance ##

# Comparing both populations that were not moved temperatures (t test)
distance_results_both <- shapiro_then_stats(r25_m25,r29_m29,"distance") # p value of 0.01841 * 

## Max Speed ##

# Ran as wilcoxon, as not normally distributed
max_speed_results_both <- shapiro_then_stats(r25_m25,r29_m29,"max_speed") # p value of 0.1677

## Average Speed ##

# Ran as t test as normally distributed
avg_speed_results_both <- shapiro_then_stats(r25_m25,r29_m29,"avg_speed") # p value of 0.2117

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#


print("# Results for distance #")
print(distance_stats)
print("# Results for max_speed #")
print(max_speed_stats)
print("# Results for avg_speed #")
print(avg_speed_stats)
